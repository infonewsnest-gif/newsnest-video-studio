# NewsNest Video Studio (v0.1)

Pick video -> pick ratio (1:1, 9:16, 4:5) -> headline -> zoom/pan -> export MP4 with template on top -> saved to Movies/NewsNest.

Build: push to GitHub, Actions -> "Build APK" -> download the artifact (debug APK).

Templates: app/src/main/assets/templates/ (last frame of each WebM). Window rects and headline zones: Templates.kt.
