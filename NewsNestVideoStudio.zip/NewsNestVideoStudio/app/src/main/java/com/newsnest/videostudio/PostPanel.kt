package com.newsnest.videostudio

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostPanel(file: File?, defaultCaption: String) {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var pageId by remember { mutableStateOf(sp.getString("fb_page_id", "") ?: "") }
    var fbToken by remember { mutableStateOf(sp.getString("fb_token", "") ?: "") }
    var ytClient by remember { mutableStateOf(sp.getString("yt_client", "") ?: "") }
    var ytSecret by remember { mutableStateOf(sp.getString("yt_secret", "") ?: "") }
    var ytRefresh by remember { mutableStateOf(sp.getString("yt_refresh", "") ?: "") }

    var caption by remember(defaultCaption) { mutableStateOf(defaultCaption) }
    var toFb by remember { mutableStateOf(true) }
    var toYt by remember { mutableStateOf(true) }
    var privacy by remember { mutableStateOf("private") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var pct by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("") }
    var dc by remember { mutableStateOf<Poster.DeviceCode?>(null) }

    fun saveCfg() {
        sp.edit().putString("fb_page_id", pageId.trim()).putString("fb_token", fbToken.trim())
            .putString("yt_client", ytClient.trim()).putString("yt_secret", ytSecret.trim())
            .putString("yt_refresh", ytRefresh).apply()
    }

    HorizontalDivider()
    Text("পোস্ট", style = MaterialTheme.typography.titleMedium)

    if (file == null) {
        Text("আগে ভিডিও তৈরি করুন, তারপর এখান থেকে পোস্ট হবে।")
    } else {
        OutlinedTextField(value = caption, onValueChange = { caption = it }, label = { Text("ক্যাপশন") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = toFb, onCheckedChange = { toFb = it }); Spacer(Modifier.width(8.dp)); Text("Facebook পেজ")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = toYt, onCheckedChange = { toYt = it }); Spacer(Modifier.width(8.dp)); Text("YouTube")
        }
        if (toYt) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("private" to "প্রাইভেট", "unlisted" to "আনলিস্টেড", "public" to "পাবলিক").forEach { (k, v) ->
                    FilterChip(selected = privacy == k, onClick = { privacy = k }, label = { Text(v) })
                }
            }
        }
        Button(
            enabled = !busy && (toFb || toYt), modifier = Modifier.fillMaxWidth(),
            onClick = {
                saveCfg()
                scope.launch {
                    busy = true; status = ""
                    try {
                        if (toFb) {
                            if (pageId.isBlank() || fbToken.isBlank()) throw ApiException("Facebook পেজ আইডি ও টোকেন সেটিংসে দিন")
                            pct = 0; status += "Facebook: আপলোড হচ্ছে…\n"
                            val id = Poster.facebookUpload(file, pageId.trim(), fbToken.trim(), caption) { pct = it }
                            status += "Facebook: হয়ে গেছে (id $id)\n"
                        }
                        if (toYt) {
                            if (ytClient.isBlank() || ytSecret.isBlank() || ytRefresh.isBlank()) throw ApiException("YouTube আগে সেটিংসে কানেক্ট করুন")
                            pct = 0; status += "YouTube: আপলোড হচ্ছে…\n"
                            val id = Poster.youtubeUpload(file, ytClient.trim(), ytSecret.trim(), ytRefresh, caption.lines().firstOrNull().orEmpty().ifBlank { "NewsNest" }, caption, privacy) { pct = it }
                            status += "YouTube: হয়ে গেছে (youtu.be/$id)\n"
                        }
                    } catch (e: Exception) {
                        status += "ব্যর্থ: ${e.message}\n"
                    } finally {
                        busy = false
                    }
                }
            }
        ) { Text("পোস্ট করুন") }
        if (busy) { LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth()); Text("$pct%") }
        if (status.isNotBlank()) Text(status)
    }

    TextButton(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "সেটিংস বন্ধ করুন" else "কানেকশন সেটিংস") }
    if (showSettings) {
        Text("Facebook", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(value = pageId, onValueChange = { pageId = it }, label = { Text("পেজ আইডি") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = fbToken, onValueChange = { fbToken = it }, label = { Text("পেজ অ্যাক্সেস টোকেন") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Text("YouTube", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(value = ytClient, onValueChange = { ytClient = it }, label = { Text("Client ID") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = ytSecret, onValueChange = { ytSecret = it }, label = { Text("Client secret") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Text(if (ytRefresh.isNotBlank()) "YouTube কানেক্টেড" else "YouTube কানেক্ট করা নেই")
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                saveCfg()
                scope.launch {
                    try {
                        val d = Poster.ytDeviceCode(ytClient.trim())
                        dc = d
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        ytRefresh = Poster.ytWaitForToken(ytClient.trim(), ytSecret.trim(), d)
                        saveCfg()
                        dc = null
                        status = "YouTube কানেক্ট হয়েছে\n"
                    } catch (e: Exception) {
                        dc = null
                        status = "কানেক্ট হয়নি: ${e.message}\n"
                    }
                }
            }
        ) { Text("YouTube কানেক্ট করুন") }
        dc?.let { Text("খোলা পেজে এই কোডটি দিন: ${it.userCode}", style = MaterialTheme.typography.titleMedium) }
        Button(onClick = { saveCfg(); showSettings = false }, modifier = Modifier.fillMaxWidth()) { Text("সেভ করুন") }
    }
}
