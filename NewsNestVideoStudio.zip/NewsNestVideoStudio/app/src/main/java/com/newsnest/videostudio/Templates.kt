package com.newsnest.videostudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint

/** One ratio template. win* = transparent window where the video goes, head* = headline zone. All in template pixels. */
data class Tpl(
    val id: String, val label: String, val asset: String,
    val w: Int, val h: Int,
    val winX: Int, val winY: Int, val winW: Int, val winH: Int,
    val headX: Int, val headY: Int, val headW: Int, val headH: Int
)

val TEMPLATES = listOf(
    Tpl("1x1", "১:১", "templates/last_1x1.png", 1080, 1080, 0, 236, 1080, 608, 60, 872, 960, 185),
    Tpl("9x16", "৯:১৬", "templates/last_9x16.png", 1080, 1920, 0, 610, 1080, 1080, 60, 1715, 960, 190),
    Tpl("4x5", "৪:৫", "templates/last_4x5.png", 1080, 1350, 0, 0, 1080, 1104, 50, 1150, 980, 185)
)

/** Template frame (with transparent window) + headline text drawn into the headline zone. */
fun buildOverlay(ctx: Context, t: Tpl, headline: String): Bitmap {
    val opts = BitmapFactory.Options().apply {
        inMutable = true
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val bmp = ctx.assets.open(t.asset).use { BitmapFactory.decodeStream(it, null, opts)!! }
    if (headline.isBlank()) return bmp

    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }
    var size = 76f
    var layout: StaticLayout
    while (true) {
        paint.textSize = size
        layout = StaticLayout.Builder.obtain(headline, 0, headline.length, paint, t.headW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.1f)
            .build()
        if (layout.height <= t.headH || size <= 28f) break
        size -= 4f
    }
    val canvas = Canvas(bmp)
    canvas.save()
    canvas.translate(t.headX.toFloat(), t.headY + (t.headH - layout.height) / 2f)
    layout.draw(canvas)
    canvas.restore()
    return bmp
}
