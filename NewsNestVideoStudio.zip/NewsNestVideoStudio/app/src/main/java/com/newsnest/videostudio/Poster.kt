package com.newsnest.videostudio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ApiException(msg: String) : Exception(msg)

object Poster {
    private const val YT_SCOPE = "https://www.googleapis.com/auth/youtube"

    data class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

    private fun form(p: Map<String, String>) =
        p.entries.joinToString("&") { "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value, "UTF-8")}" }

    private fun body(c: HttpURLConnection): String {
        val s = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return s?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun json(s: String): JSONObject = try { JSONObject(s.ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }

    private fun postForm(url: String, params: Map<String, String>): Pair<Int, JSONObject> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.outputStream.use { it.write(form(params).toByteArray()) }
        val code = c.responseCode
        val j = json(body(c))
        c.disconnect()
        return code to j
    }

    private fun copy(i: InputStream, o: OutputStream, total: Long, onProgress: (Int) -> Unit) {
        val buf = ByteArray(64 * 1024)
        var done = 0L
        var last = -1
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            o.write(buf, 0, n)
            done += n
            val pct = if (total > 0) (done * 100 / total).toInt() else 0
            if (pct != last) { last = pct; onProgress(pct) }
        }
    }

    /** Facebook Page video upload. Returns the new video id. */
    suspend fun facebookUpload(file: File, pageId: String, token: String, description: String, onProgress: (Int) -> Unit): String =
        withContext(Dispatchers.IO) {
            val b = "----nn" + System.currentTimeMillis()
            fun field(n: String, v: String) = "--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n"
            val head = (field("access_token", token) + field("description", description) +
                "--$b\r\nContent-Disposition: form-data; name=\"source\"; filename=\"${file.name}\"\r\nContent-Type: video/mp4\r\n\r\n").toByteArray()
            val tail = "\r\n--$b--\r\n".toByteArray()
            val c = URL("https://graph-video.facebook.com/v21.0/$pageId/videos").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 30000
            c.readTimeout = 600000
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.setFixedLengthStreamingMode(head.size + file.length() + tail.size)
            c.outputStream.use { o ->
                o.write(head)
                file.inputStream().use { copy(it, o, file.length(), onProgress) }
                o.write(tail)
            }
            val code = c.responseCode
            val j = json(body(c))
            c.disconnect()
            if (code !in 200..299) throw ApiException(j.optJSONObject("error")?.optString("message") ?: "Facebook error $code")
            j.optString("id")
        }

    suspend fun ytDeviceCode(clientId: String): DeviceCode = withContext(Dispatchers.IO) {
        val (code, j) = postForm("https://oauth2.googleapis.com/device/code", mapOf("client_id" to clientId, "scope" to YT_SCOPE))
        if (code != 200) throw ApiException(j.optString("error_description", "Google error $code"))
        DeviceCode(j.getString("device_code"), j.getString("user_code"), j.getString("verification_url"), j.optInt("interval", 5), j.optInt("expires_in", 1800))
    }

    /** Waits until the user approves on google.com/device; returns the refresh token. */
    suspend fun ytWaitForToken(clientId: String, secret: String, dc: DeviceCode): String {
        var waited = 0
        while (waited < dc.expiresIn) {
            delay(dc.interval * 1000L)
            waited += dc.interval
            val (code, j) = withContext(Dispatchers.IO) {
                postForm(
                    "https://oauth2.googleapis.com/token",
                    mapOf(
                        "client_id" to clientId, "client_secret" to secret,
                        "device_code" to dc.deviceCode,
                        "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
                    )
                )
            }
            if (code == 200) return j.getString("refresh_token")
            val err = j.optString("error")
            if (err != "authorization_pending" && err != "slow_down") throw ApiException(j.optString("error_description", err))
        }
        throw ApiException("সময় শেষ হয়ে গেছে, আবার চেষ্টা করুন")
    }

    private suspend fun ytAccessToken(clientId: String, secret: String, refresh: String): String = withContext(Dispatchers.IO) {
        val (code, j) = postForm(
            "https://oauth2.googleapis.com/token",
            mapOf("client_id" to clientId, "client_secret" to secret, "refresh_token" to refresh, "grant_type" to "refresh_token")
        )
        if (code != 200) throw ApiException(j.optString("error_description", "Google error $code"))
        j.getString("access_token")
    }

    /** YouTube resumable upload. privacy = private | unlisted | public. Returns the video id. */
    suspend fun youtubeUpload(
        file: File, clientId: String, secret: String, refresh: String,
        title: String, description: String, privacy: String, onProgress: (Int) -> Unit
    ): String {
        val access = ytAccessToken(clientId, secret, refresh)
        return withContext(Dispatchers.IO) {
            val meta = JSONObject()
                .put("snippet", JSONObject().put("title", title.take(100)).put("description", description).put("categoryId", "25"))
                .put("status", JSONObject().put("privacyStatus", privacy).put("selfDeclaredMadeForKids", false))
            val start = URL("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
                .openConnection() as HttpURLConnection
            start.requestMethod = "POST"
            start.doOutput = true
            start.setRequestProperty("Authorization", "Bearer $access")
            start.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            start.setRequestProperty("X-Upload-Content-Length", file.length().toString())
            start.setRequestProperty("X-Upload-Content-Type", "video/mp4")
            start.outputStream.use { it.write(meta.toString().toByteArray()) }
            val sc = start.responseCode
            val loc = start.getHeaderField("Location")
            if (sc !in 200..299 || loc == null) {
                val j = json(body(start))
                start.disconnect()
                throw ApiException(j.optJSONObject("error")?.optString("message") ?: "YouTube error $sc")
            }
            start.disconnect()

            val put = URL(loc).openConnection() as HttpURLConnection
            put.requestMethod = "PUT"
            put.doOutput = true
            put.connectTimeout = 30000
            put.readTimeout = 600000
            put.setRequestProperty("Content-Type", "video/mp4")
            put.setFixedLengthStreamingMode(file.length())
            put.outputStream.use { o -> file.inputStream().use { copy(it, o, file.length(), onProgress) } }
            val code = put.responseCode
            val j = json(body(put))
            put.disconnect()
            if (code !in 200..299) throw ApiException(j.optJSONObject("error")?.optString("message") ?: "YouTube error $code")
            j.optString("id")
        }
    }
}
