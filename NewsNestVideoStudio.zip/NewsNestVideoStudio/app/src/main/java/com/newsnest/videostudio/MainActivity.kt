package com.newsnest.videostudio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { StudioScreen() } } }
    }
}

private data class VideoInfo(val w: Int, val h: Int, val durationMs: Long)

private fun readInfo(ctx: Context, uri: Uri): VideoInfo? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: return null
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: return null
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        if (rot == 90 || rot == 270) { val x = w; w = h; h = x }
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        VideoInfo(w, h, dur)
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

private fun saveToGallery(ctx: Context, f: File): Uri? {
    val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NewsNest")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val res = ctx.contentResolver
    val uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
    res.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    v.clear()
    v.put(MediaStore.Video.Media.IS_PENDING, 0)
    res.update(uri, v, null, null)
    return uri
}

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun StudioScreen() {
    val ctx = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var tplIndex by remember { mutableIntStateOf(0) }
    var headline by remember { mutableStateOf("") }
    var zoom by remember { mutableFloatStateOf(1f) }
    var ox by remember { mutableFloatStateOf(0f) }
    var oy by remember { mutableFloatStateOf(0f) }
    var progress by remember { mutableIntStateOf(-1) }
    var message by remember { mutableStateOf<String?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var lastFile by remember { mutableStateOf<File?>(null) }
    val exporter = remember { Exporter(ctx) }

    val tpl = TEMPLATES[tplIndex]
    val overlay = remember(tplIndex, headline) { buildOverlay(ctx, tpl, headline) }

    val exo = remember {
        ExoPlayer.Builder(ctx).build().apply { repeatMode = Player.REPEAT_MODE_ALL; volume = 0f }
    }
    DisposableEffect(Unit) { onDispose { exporter.cancel(); exo.release() } }
    LaunchedEffect(videoUri) {
        videoUri?.let { exo.setMediaItem(MediaItem.fromUri(it)); exo.prepare(); exo.playWhenReady = true }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            videoUri = uri
            info = readInfo(ctx, uri)
            zoom = 1f; ox = 0f; oy = 0f; savedUri = null; message = null
            if (info == null) message = "ভিডিওটি পড়া যায়নি"
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("নিউজ ভিডিও স্টুডিও", style = MaterialTheme.typography.titleLarge)

        Button(onClick = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }, modifier = Modifier.fillMaxWidth()) { Text("ভিডিও বাছুন") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TEMPLATES.forEachIndexed { i, t ->
                FilterChip(selected = i == tplIndex, onClick = { tplIndex = i }, label = { Text(t.label) })
            }
        }

        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val d = LocalDensity.current
            val maxWpx = with(d) { maxWidth.toPx() }
            val maxHpx = with(d) { 420.dp.toPx() }
            val s = minOf(maxWpx / tpl.w, maxHpx / tpl.h)
            val canvasW = with(d) { (tpl.w * s).toDp() }
            val canvasH = with(d) { (tpl.h * s).toDp() }
            val boxWpx = tpl.winW * s
            val boxHpx = tpl.winH * s

            Box(Modifier.width(canvasW).height(canvasH).background(Color.Black)) {
                Box(
                    Modifier
                        .offset(with(d) { (tpl.winX * s).toDp() }, with(d) { (tpl.winY * s).toDp() })
                        .size(with(d) { boxWpx.toDp() }, with(d) { boxHpx.toDp() })
                        .clipToBounds()
                        .background(Color(0xFF333333))
                ) {
                    val inf = info
                    if (inf != null) {
                        val va = inf.w.toFloat() / inf.h
                        val cw: Float
                        val ch: Float
                        if (va > boxWpx / boxHpx) { ch = boxHpx; cw = boxHpx * va } else { cw = boxWpx; ch = boxWpx / va }
                        val tx = -ox * (zoom * cw - boxWpx) / 2f
                        val ty = -oy * (zoom * ch - boxHpx) / 2f
                        AndroidView(
                            modifier = Modifier.fillMaxSize().graphicsLayer(
                                scaleX = zoom, scaleY = zoom, translationX = tx, translationY = ty
                            ),
                            factory = { c ->
                                PlayerView(c).apply {
                                    useController = false
                                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    player = exo
                                }
                            }
                        )
                    }
                }
                Image(
                    bitmap = overlay.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
            }
        }

        OutlinedTextField(
            value = headline, onValueChange = { headline = it },
            label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth()
        )

        Text("জুম")
        Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..3f)
        Text("ডানে-বামে")
        Slider(value = ox, onValueChange = { ox = it }, valueRange = -1f..1f)
        Text("ওপরে-নিচে")
        Slider(value = oy, onValueChange = { oy = it }, valueRange = -1f..1f)

        val exporting = progress >= 0
        Button(
            enabled = info != null && !exporting,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val inf = info ?: return@Button
                val uri = videoUri ?: return@Button
                val out = File(ctx.cacheDir, "NewsNest_${System.currentTimeMillis()}.mp4")
                progress = 0; message = null; savedUri = null
                exporter.start(
                    uri, tpl, buildOverlay(ctx, tpl, headline), inf.w, inf.h, zoom, ox, oy, out,
                    onProgress = { progress = it },
                    onDone = { err ->
                        progress = -1
                        if (err == null) {
                            lastFile = out
                            savedUri = saveToGallery(ctx, out)
                            message = if (savedUri != null) "ভিডিও গ্যালারিতে সেভ হয়েছে" else "সেভ করা যায়নি"
                        } else {
                            message = "এক্সপোর্ট হয়নি: ${err.message}"
                        }
                    }
                )
            }
        ) { Text("তৈরি করুন") }

        if (progress >= 0) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            Text("$progress%")
        }
        message?.let { Text(it) }
        savedUri?.let { u ->
            OutlinedButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, u)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "শেয়ার করুন"))
            }, modifier = Modifier.fillMaxWidth()) { Text("শেয়ার করুন") }
        }

        PostPanel(lastFile, headline)
    }
}
