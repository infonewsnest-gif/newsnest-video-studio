package com.newsnest.videostudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Crop
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File

/**
 * Pipeline per frame: crop video to window aspect (zoom/pan) -> stretch to template canvas ->
 * matrix shrinks it back (undistorted) into the template window -> template frame overlaid on top.
 */
@UnstableApi
class Exporter(private val context: Context) {
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())

    fun start(
        video: Uri, t: Tpl, overlay: Bitmap,
        vw: Int, vh: Int, zoom: Float, ox: Float, oy: Float,
        out: File,
        onProgress: (Int) -> Unit,
        onDone: (Throwable?) -> Unit
    ) {
        val va = vw.toFloat() / vh
        val wa = t.winW.toFloat() / t.winH
        var fw: Float
        var fh: Float
        if (va > wa) { fh = 1f; fw = wa / va } else { fw = 1f; fh = va / wa }
        fw /= zoom
        fh /= zoom
        val cx = 0.5f + ox * (1f - fw) / 2f
        val cy = 0.5f + oy * (1f - fh) / 2f
        val left = 2f * (cx - fw / 2f) - 1f
        val right = 2f * (cx + fw / 2f) - 1f
        val top = 1f - 2f * (cy - fh / 2f)
        val bottom = 1f - 2f * (cy + fh / 2f)

        val matrix = Matrix().apply {
            setScale(t.winW.toFloat() / t.w, t.winH.toFloat() / t.h)
            val cxp = t.winX + t.winW / 2f
            val cyp = t.winY + t.winH / 2f
            postTranslate(2f * cxp / t.w - 1f, 1f - 2f * cyp / t.h)
        }

        val effects = Effects(
            emptyList(),
            listOf(
                Crop(left, right, bottom, top),
                Presentation.createForWidthAndHeight(t.w, t.h, Presentation.LAYOUT_STRETCH_TO_FIT),
                MatrixTransformation { matrix },
                OverlayEffect(ImmutableList.of<TextureOverlay>(BitmapOverlay.createStaticBitmapOverlay(overlay)))
            )
        )
        val item = EditedMediaItem.Builder(MediaItem.fromUri(video)).setEffects(effects).build()

        val tr = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setEncoderFactory(
                DefaultEncoderFactory.Builder(context)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(8_000_000).build())
                    .build()
            )
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    onDone(null)
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    handler.removeCallbacksAndMessages(null)
                    onDone(exportException)
                }
            })
            .build()
        transformer = tr
        tr.start(item, out.absolutePath)

        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                if (tr.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress)
                handler.postDelayed(this, 300)
            }
        }
        handler.post(poll)
    }

    fun cancel() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
    }
}
